import React from 'react';
import './Footer.css';

const Footer = () => (
  <div>
    <h3 className="footer">A Microverse Capstone Project by Albert Antwi</h3>
  </div>
);

export default Footer;
